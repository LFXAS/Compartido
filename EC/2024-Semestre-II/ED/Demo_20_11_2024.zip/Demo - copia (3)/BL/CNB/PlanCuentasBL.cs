﻿using Demo.DAL.CNB;
using Demo.DTO.CNB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo.BL.CNB
{
    public class PlanCuentasBL
    {
        private readonly PlanCuentasDAL _planCuentasDal;

        public PlanCuentasBL()
        {
            _planCuentasDal = new PlanCuentasDAL();
        }

        public List<PlanCuentasDTO> ObtenerPlanCuentas()
        {
            return _planCuentasDal.ObtenerPlanCuentas();
        }

        public List<PlanCuentasDTO> ObtenerPlanCuentasConFiltro(string filtro)
        {
            return _planCuentasDal.ObtenerPlanCuentasConFiltro(filtro);
        }

        public void GuardarPlanCuentas(int codigo, string descripcion, string tipoCuenta, DateTime fechaCreacion, string usuarioCrea, bool estado)
        {
            var planCuentas = new PlanCuentasDTO
            {
                Codigo = codigo,
                Descripcion = descripcion,
                TipoCuenta = tipoCuenta,
                FechaCreacion = fechaCreacion,
                UsuarioCrea = usuarioCrea,
                Estado = estado
            };

            _planCuentasDal.InsertarPlanCuentas(planCuentas);
        }

        public PlanCuentasDTO ObtenerPlanCuentasPorId(int id)
        {
            return _planCuentasDal.ObtenerPlanCuentasPorId(id);
        }

        public void ActualizarPlanCuentas(PlanCuentasDTO planCuentas)
        {
            _planCuentasDal.ActualizarPlanCuentas(planCuentas);
        }

        public void EliminarPlanCuentas(int id)
        {
            _planCuentasDal.EliminarPlanCuentas(id);
        }
    }
}
