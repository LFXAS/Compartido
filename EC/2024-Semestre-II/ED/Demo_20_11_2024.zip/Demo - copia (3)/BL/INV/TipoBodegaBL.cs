﻿using Demo.DAL.INV;
using Demo.DTO.INV;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo.BL.INV
{
    public class TipoBodegaBL
    {
        private readonly TipoBodegaDAL _tipoBodegaDal;

        public TipoBodegaBL()
        {
            _tipoBodegaDal = new TipoBodegaDAL();
        }

        public List<TipoBodegaDTO> ObtenerTipoBodegas()
        {
            return _tipoBodegaDal.ObtenerTipoBodegas();
        }

        public List<TipoBodegaDTO> ObtenerTipoBodegaConFiltro(string filtro)
        {
            return _tipoBodegaDal.ObtenerTipoBodegaConFiltro(filtro);
        }

        public void GuardarTipoBodega(string descripcion, DateTime fechaCreacion, string usuarioCrea, bool estado)
        {
            var tipoBodega = new TipoBodegaDTO
            {
                Descripcion = descripcion,
                FechaCreacion = fechaCreacion,
                UsuarioCrea = usuarioCrea,
                Estado = estado
            };

            _tipoBodegaDal.InsertarTipoBodega(tipoBodega);
        }

        public TipoBodegaDTO ObtenerTipoBodegaPorId(int id)
        {
            return _tipoBodegaDal.ObtenerTipoBodegaPorId(id);
        }

        public void ActualizarTipoBodega(TipoBodegaDTO tipoBodega)
        {
            _tipoBodegaDal.ActualizarTipoBodega(tipoBodega);
        }

        public void EliminarTipoBodega(int id)
        {
            _tipoBodegaDal.EliminarTipoBodega(id);
        }
    }
}
