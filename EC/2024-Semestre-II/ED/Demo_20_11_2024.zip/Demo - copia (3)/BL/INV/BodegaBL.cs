﻿using Demo.DAL.INV;
using Demo.DTO.INV;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo.BL.INV
{
    public class BodegaBL
    {
        private readonly BodegaDAL _bodegaDal;

        // Constructor que recibe la instancia de BodegaDAL
        public BodegaBL()
        {
            _bodegaDal = new BodegaDAL();
        }

        // Método para obtener todas las bodegas
        public List<BodegaDTO> ObtenerBodegas()
        {
            return _bodegaDal.ObtenerBodegas();
        }

        // Método para obtener las bodegas con sus tipos de bodegas asociadas
        public List<BodegaDTO> ObtenerBodegasConTipoBodega()
        {
            return _bodegaDal.ObtenerBodegasConTipoBodega();
        }

        public List<BodegaDTO> ObtenerBodegasPorTipoBodega(int tipoBodegaId)
        {
            return _bodegaDal.ObtenerBodegasPorTipoBodega(tipoBodegaId);
        }

        public List<BodegaDTO> ObtenerBodegasConFiltro(string filtro)
        {
            return _bodegaDal.ObtenerBodegasConFiltro(filtro);
        }


        // Método para obtener una bodega por Id
        public BodegaDTO ObtenerBodegaPorId(int id)
        {
            return _bodegaDal.ObtenerBodegaPorId(id);
        }

        // Método para agregar una nueva bodega
        public void GuardarBodega(string codigo, string descripcion, int tipoBodegaId, DateTime fechaCreacion, string usuarioCrea, bool estado)
        {
            var nuevaBodega = new BodegaDTO
            {
                Codigo = codigo,
                Descripcion = descripcion,
                TipoBodegaId = tipoBodegaId,
                FechaCreacion = fechaCreacion,
                UsuarioCrea = usuarioCrea,
                Estado = estado
            };

            _bodegaDal.InsertarBodega(nuevaBodega);
        }

        // Método para actualizar una bodega existente
        public void ActualizarBodega(int id, string codigo, string descripcion, int tipoBodegaId, DateTime fechaModificacion, string usuarioModifica, bool estado)
        {
            var bodegaExistente = _bodegaDal.ObtenerBodegaPorId(id);
            if (bodegaExistente != null)
            {
                bodegaExistente.Codigo = codigo;
                bodegaExistente.Descripcion = descripcion;
                bodegaExistente.TipoBodegaId = tipoBodegaId;
                bodegaExistente.FechaModificacion= fechaModificacion;
                bodegaExistente.UsuarioModifica= usuarioModifica;
                bodegaExistente.Estado = estado;

                _bodegaDal.ActualizarBodega(bodegaExistente);
            }
        }

        // Método para eliminar una bodega por Id
        public void EliminarBodega(int id)
        {
            _bodegaDal.EliminarBodega(id);
        }
    }
}
