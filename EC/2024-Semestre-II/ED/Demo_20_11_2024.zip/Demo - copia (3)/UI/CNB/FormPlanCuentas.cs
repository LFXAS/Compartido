﻿using Demo.BL.CNB;
using Demo.DTO.CNB;
using Demo.BL.INV;
using Demo.DTO.INV;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Demo.UI.CNB
{
    public partial class FormPlanCuentas : Form
    {
        private readonly PlanCuentasBL _planCuentasBl;
        private int Id;
        private DateTime FechaCreacion;
        private string UsuarioCrea = string.Empty;

        public FormPlanCuentas()
        {
            InitializeComponent();
            _planCuentasBl = new PlanCuentasBL();
        }

        // Método para cargar los ítems en el DataGridView
        private void CargarPlanCuentas()
        {
            var planCuentas = _planCuentasBl.ObtenerPlanCuentas();
            dataGridViewPlanCuentas.DataSource = planCuentas.Select(i => new
            {
                i.Id,
                i.Codigo,
                i.Descripcion,
                i.TipoCuenta,
                i.FechaCreacion,
                i.UsuarioCrea,
                i.FechaModificacion,
                i.UsuarioModifica,
                Estado = i.Estado ? "Activo" : "Inactivo"  // Cambiar visualización del estado
            }).ToList();
            FormateaDataGridView();
        }

        private void FormateaDataGridView()
        {
            // Configurar el DataGridView para seleccionar la fila completa al hacer clic en una celda
            dataGridViewPlanCuentas.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            // Deshabilitar la selección de múltiples filas (opcional)
            dataGridViewPlanCuentas.MultiSelect = false;

            // Deshabilitar la selección de celdas individuales (opcional)
            dataGridViewPlanCuentas.CellBorderStyle = DataGridViewCellBorderStyle.None;

            // Personalizar las columnas
            dataGridViewPlanCuentas.Columns["Id"].HeaderText = "Id";
            dataGridViewPlanCuentas.Columns["Codigo"].HeaderText = "Código";
            dataGridViewPlanCuentas.Columns["Descripcion"].HeaderText = "Descripción";
            dataGridViewPlanCuentas.Columns["TipoCuenta"].HeaderText = "Tipo de cuenta";
            dataGridViewPlanCuentas.Columns["FechaCreacion"].HeaderText = "Fecha de creación";
            dataGridViewPlanCuentas.Columns["UsuarioCrea"].HeaderText = "Usuario crea";
            dataGridViewPlanCuentas.Columns["FechaModificacion"].HeaderText = "Fecha de modificación";
            dataGridViewPlanCuentas.Columns["UsuarioModifica"].HeaderText = "Usuario modifica";
            dataGridViewPlanCuentas.Columns["Estado"].HeaderText = "Estado";

            // Configura las filas alternas para que se vean con un fondo diferente
            dataGridViewPlanCuentas.AlternatingRowsDefaultCellStyle.BackColor = Color.LightGray;

            // Cambiar el color de la fila seleccionada
            dataGridViewPlanCuentas.DefaultCellStyle.SelectionBackColor = Color.Blue;
            dataGridViewPlanCuentas.DefaultCellStyle.SelectionForeColor = Color.White;

            // Ajustar el estilo de la fuente en las celdas
            dataGridViewPlanCuentas.DefaultCellStyle.Font = new Font("Segoe UI", 9);

            // Cambiar el modo de ajuste de las columnas
            dataGridViewPlanCuentas.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void SeleccionarPrimeraFila()
        {
            if (dataGridViewPlanCuentas.Rows.Count > 0) // Verificar que haya filas en el DataGridView
            {
                dataGridViewPlanCuentas.ClearSelection(); // Limpiar cualquier selección previa
                dataGridViewPlanCuentas.Rows[0].Selected = true; // Seleccionar la primera fila

                // Llamar al método que maneja la carga de datos en los controles
                CargarDatosDeFilaSeleccionada();
            }
        }

        private void CargarDatosDeFilaSeleccionada()
        {
            if (dataGridViewPlanCuentas.SelectedRows.Count > 0) // Verificar si hay filas seleccionadas
            {
                DataGridViewRow row = dataGridViewPlanCuentas.SelectedRows[0]; // Obtener la primera fila seleccionada

                // Cargar los valores de la fila seleccionada en los controles
                Id = (int)row.Cells["Id"].Value;
                textBoxCodigo.Text = row.Cells["Codigo"].Value?.ToString();
                textBoxDescripcion.Text = row.Cells["Descripcion"].Value?.ToString();
                textBoxTipoCuenta.Text = row.Cells["TipoCuenta"].Value?.ToString();

                // Asignar otros valores como el estado o el usuario creador
                UsuarioCrea = row.Cells["UsuarioCrea"].Value?.ToString() ?? string.Empty;

                if (row.Cells["Estado"].Value.ToString() == "Activo")
                {
                    checkBoxEstado.Checked = true;
                }
                else
                {
                    checkBoxEstado.Checked = false; // Valor predeterminado si no se puede convertir
                }
            }
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            // Validar los campos antes de guardar
            if (string.IsNullOrEmpty(textBoxCodigo.Text))
            {
                MessageBox.Show("El códgio es requerido.");
                return;
            }

            if (string.IsNullOrEmpty(textBoxDescripcion.Text))
            {
                MessageBox.Show("La descripción es requerida.");
                return;
            }

            if (string.IsNullOrEmpty(textBoxTipoCuenta.Text))
            {
                MessageBox.Show("El tipo de cuenta es requerido.");
                return;
            }

            var codigo = Convert.ToInt32(textBoxCodigo.Text);
            var descripcion = textBoxDescripcion.Text;
            var tipoCuenta = textBoxTipoCuenta.Text;
            var fechaCreacion = DateTime.Now;
            var usuarioCrea = "UsuarioDemo";
            var estado = checkBoxEstado.Checked;

            // Guardar la marca usando la capa de lógica de negocio
            _planCuentasBl.GuardarPlanCuentas(codigo, descripcion, tipoCuenta, fechaCreacion, usuarioCrea, estado);
            CargarPlanCuentas();
            MessageBox.Show("Plan de cuentas guardado correctamente.");

            // Limpiar los campos
            textBoxCodigo.Text = string.Empty;
            textBoxDescripcion.Text = string.Empty;
            textBoxTipoCuenta.Text = string.Empty;
            checkBoxEstado.Checked = false;
            textBoxFiltro.Text = string.Empty;
        }

        private void buttonCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonLimpiar_Click(object sender, EventArgs e)
        {
            SeleccionarPrimeraFila();
            // Limpiar los campos
            textBoxCodigo.Text = string.Empty;
            textBoxDescripcion.Text = string.Empty;
            textBoxTipoCuenta.Text = string.Empty;
            checkBoxEstado.Checked = false;
            textBoxFiltro.Text = string.Empty;

            btnAgregar.Enabled = true;
            btnActualizar.Enabled = false;
            btnEliminar.Enabled = false;
            textBoxCodigo.Focus();
        }

        private void CargarDataGridConFiltro(string filtro)
        {
            var planCuentasFiltradas = _planCuentasBl.ObtenerPlanCuentasConFiltro(filtro);

            dataGridViewPlanCuentas.DataSource = planCuentasFiltradas
                .Select(s => new
                {
                    s.Id,
                    s.Codigo,
                    s.Descripcion,
                    s.TipoCuenta,
                    s.FechaCreacion,
                    s.UsuarioCrea,
                    s.FechaModificacion,
                    s.UsuarioModifica,
                    Estado = s.Estado ? "Activo" : "Inactivo"  // Cambiar visualización del estado
                })
                .ToList();

            FormateaDataGridView();
        }
        private void buttonFiltrar_Click(object sender, EventArgs e)
        {
            string filtro = textBoxFiltro.Text;
            CargarDataGridConFiltro(filtro); // O FiltrarDataGridView(filtro) si es filtrado en memoria
        }

        private void dataGridViewPlanCuentas_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Verificar que se haya seleccionado una fila válida
            if (e.RowIndex >= 0)
            {
                // Obtener el ítem seleccionado
                DataGridViewRow row = dataGridViewPlanCuentas.Rows[e.RowIndex];

                // Cargar los valores en los controles del formulario                
                Id = Convert.ToInt32(row.Cells["Id"].Value);
                textBoxCodigo.Text = row.Cells["Codigo"].Value?.ToString();
                textBoxDescripcion.Text = row.Cells["Descripcion"].Value?.ToString();
                textBoxTipoCuenta.Text = row.Cells["TipoCuenta"].Value?.ToString();

                FechaCreacion = Convert.ToDateTime(row.Cells["FechaCreacion"].Value);
                UsuarioCrea = row.Cells["UsuarioCrea"].Value?.ToString() ?? string.Empty;

                if (row.Cells["Estado"].Value.ToString() == "Activo")
                {
                    checkBoxEstado.Checked = true;
                }
                else
                {
                    checkBoxEstado.Checked = false; // Valor predeterminado si no se puede convertir
                }

                // Habilitar los botones de actualización y eliminación
                btnAgregar.Enabled = false;
                btnActualizar.Enabled = true;
                btnEliminar.Enabled = true;
            }
        }

        private void dataGridViewPlanCuentas_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridViewPlanCuentas.SelectedRows.Count > 0) // Verificar si hay filas seleccionadas
            {
                DataGridViewRow row = dataGridViewPlanCuentas.SelectedRows[0]; // Obtener la primera fila seleccionada

                // Cargar los valores de la fila seleccionada en los controles
                Id = (int)row.Cells["Id"].Value;
                textBoxCodigo.Text = row.Cells["Codigo"].Value?.ToString();
                textBoxDescripcion.Text = row.Cells["Descripcion"].Value?.ToString();
                textBoxTipoCuenta.Text = row.Cells["TipoCuenta"].Value?.ToString();

                // Asignar otros valores como el estado o el usuario creador
                UsuarioCrea = row.Cells["UsuarioCrea"].Value?.ToString() ?? string.Empty;

                if (row.Cells["Estado"].Value.ToString() == "Activo")
                {
                    checkBoxEstado.Checked = true;
                }
                else
                {
                    checkBoxEstado.Checked = false; // Valor predeterminado si no se puede convertir
                }

                // Habilitar los botones de actualización y eliminación
                btnAgregar.Enabled = false;
                btnActualizar.Enabled = true;
                btnEliminar.Enabled = true;
            }
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            var planCuentas = new PlanCuentasDTO
            {
                Id = this.Id,
                Codigo = Convert.ToInt32(textBoxCodigo.Text),
                Descripcion = textBoxDescripcion.Text,
                TipoCuenta = textBoxTipoCuenta.Text,
                FechaCreacion = this.FechaCreacion,
                UsuarioCrea = this.UsuarioCrea,
                FechaModificacion = DateTime.Now,
                UsuarioModifica = "UsuarioDemo",
                Estado = checkBoxEstado.Checked
            };

            _planCuentasBl.ActualizarPlanCuentas(planCuentas);
            CargarPlanCuentas();
            textBoxDescripcion.Text = string.Empty;
            checkBoxEstado.Checked = false;
            textBoxFiltro.Text = string.Empty;
            // Seleccionar la primera fila y cargar sus datos
            SeleccionarPrimeraFila();
            MessageBox.Show("Plan de cuentas actualizado correctamente.");
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            int id = this.Id;
            _planCuentasBl.EliminarPlanCuentas(id);
            CargarPlanCuentas();
            // Limpiar los campos
            textBoxCodigo.Text = string.Empty;
            textBoxDescripcion.Text = string.Empty;
            textBoxTipoCuenta.Text = string.Empty;
            checkBoxEstado.Checked = false;
            textBoxFiltro.Text = string.Empty;
            // Seleccionar la primera fila y cargar sus datos
            SeleccionarPrimeraFila();
            MessageBox.Show("Plan de cuentas eliminado correctamente.");
        }

        private void FormPlanCuentas_Load(object sender, EventArgs e)
        {
            // Cargar las marcas en el DataGridView
            CargarPlanCuentas();

            // Asegurarse de que el DataGridView permita el enfoque mediante el tabulador
            dataGridViewPlanCuentas.TabStop = true;
            dataGridViewPlanCuentas.TabIndex = 0;

            // Usar BeginInvoke para asegurar que el foco se establece correctamente
            this.BeginInvoke(new Action(() =>
            {
                // Establecer el foco en el DataGridView
                dataGridViewPlanCuentas.Focus();

                // Seleccionar la primera celda automáticamente
                if (dataGridViewPlanCuentas.Rows.Count > 0)
                {
                    dataGridViewPlanCuentas.ClearSelection();
                    dataGridViewPlanCuentas.Rows[0].Selected = true;
                    dataGridViewPlanCuentas.CurrentCell = dataGridViewPlanCuentas.Rows[0].Cells[0]; // Seleccionar la primera celda

                    // Para asegurarte de que el grid esté enfocado y listo para navegar
                    dataGridViewPlanCuentas.Focus(); // Foco final en el grid
                }
            }));
        }
    }
}
