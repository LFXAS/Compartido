﻿namespace Demo.UI.CNB
{
    partial class FormPlanCuentas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox3 = new GroupBox();
            label2 = new Label();
            buttonFiltrar = new Button();
            textBoxFiltro = new TextBox();
            btnAgregar = new Button();
            btnActualizar = new Button();
            btnEliminar = new Button();
            groupBox2 = new GroupBox();
            dataGridViewPlanCuentas = new DataGridView();
            buttonCancelar = new Button();
            buttonLimpiar = new Button();
            groupBox1 = new GroupBox();
            label4 = new Label();
            label3 = new Label();
            textBoxTipoCuenta = new TextBox();
            textBoxCodigo = new TextBox();
            checkBoxEstado = new CheckBox();
            textBoxDescripcion = new TextBox();
            label1 = new Label();
            groupBox3.SuspendLayout();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewPlanCuentas).BeginInit();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(label2);
            groupBox3.Controls.Add(buttonFiltrar);
            groupBox3.Controls.Add(textBoxFiltro);
            groupBox3.Location = new Point(9, 129);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(542, 87);
            groupBox3.TabIndex = 25;
            groupBox3.TabStop = false;
            groupBox3.Text = "Filtros";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(16, 40);
            label2.Name = "label2";
            label2.Size = new Size(72, 15);
            label2.TabIndex = 9;
            label2.Text = "Descripción:";
            // 
            // buttonFiltrar
            // 
            buttonFiltrar.Location = new Point(341, 32);
            buttonFiltrar.Name = "buttonFiltrar";
            buttonFiltrar.Size = new Size(100, 30);
            buttonFiltrar.TabIndex = 8;
            buttonFiltrar.Text = "Buscar";
            buttonFiltrar.UseVisualStyleBackColor = true;
            buttonFiltrar.Click += buttonFiltrar_Click;
            // 
            // textBoxFiltro
            // 
            textBoxFiltro.Location = new Point(94, 35);
            textBoxFiltro.Name = "textBoxFiltro";
            textBoxFiltro.Size = new Size(241, 23);
            textBoxFiltro.TabIndex = 7;
            // 
            // btnAgregar
            // 
            btnAgregar.Location = new Point(9, 492);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new Size(100, 30);
            btnAgregar.TabIndex = 22;
            btnAgregar.Text = "Agregar";
            btnAgregar.Click += btnAgregar_Click;
            // 
            // btnActualizar
            // 
            btnActualizar.Enabled = false;
            btnActualizar.Location = new Point(115, 492);
            btnActualizar.Name = "btnActualizar";
            btnActualizar.Size = new Size(100, 30);
            btnActualizar.TabIndex = 23;
            btnActualizar.Text = "Actualizar";
            btnActualizar.Click += btnActualizar_Click;
            // 
            // btnEliminar
            // 
            btnEliminar.Enabled = false;
            btnEliminar.Location = new Point(221, 492);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new Size(100, 30);
            btnEliminar.TabIndex = 24;
            btnEliminar.Text = "Eliminar";
            btnEliminar.Click += btnEliminar_Click;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(dataGridViewPlanCuentas);
            groupBox2.Location = new Point(9, 222);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(542, 264);
            groupBox2.TabIndex = 21;
            groupBox2.TabStop = false;
            groupBox2.Text = "Listado de marcas";
            // 
            // dataGridViewPlanCuentas
            // 
            dataGridViewPlanCuentas.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewPlanCuentas.Location = new Point(6, 20);
            dataGridViewPlanCuentas.Name = "dataGridViewPlanCuentas";
            dataGridViewPlanCuentas.Size = new Size(530, 236);
            dataGridViewPlanCuentas.TabIndex = 0;
            dataGridViewPlanCuentas.CellClick += dataGridViewPlanCuentas_CellClick;
            dataGridViewPlanCuentas.SelectionChanged += dataGridViewPlanCuentas_SelectionChanged;
            // 
            // buttonCancelar
            // 
            buttonCancelar.Location = new Point(451, 492);
            buttonCancelar.Name = "buttonCancelar";
            buttonCancelar.Size = new Size(100, 30);
            buttonCancelar.TabIndex = 20;
            buttonCancelar.Text = "Cancelar";
            buttonCancelar.UseVisualStyleBackColor = true;
            buttonCancelar.Click += buttonCancelar_Click;
            // 
            // buttonLimpiar
            // 
            buttonLimpiar.Location = new Point(345, 492);
            buttonLimpiar.Name = "buttonLimpiar";
            buttonLimpiar.Size = new Size(100, 30);
            buttonLimpiar.TabIndex = 19;
            buttonLimpiar.Text = "Limpiar";
            buttonLimpiar.UseVisualStyleBackColor = true;
            buttonLimpiar.Click += buttonLimpiar_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(textBoxTipoCuenta);
            groupBox1.Controls.Add(textBoxCodigo);
            groupBox1.Controls.Add(checkBoxEstado);
            groupBox1.Controls.Add(textBoxDescripcion);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(10, 13);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(542, 116);
            groupBox1.TabIndex = 18;
            groupBox1.TabStop = false;
            groupBox1.Text = "Información";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(16, 83);
            label4.Name = "label4";
            label4.Size = new Size(72, 15);
            label4.TabIndex = 9;
            label4.Text = "Tipo cuenta:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(16, 25);
            label3.Name = "label3";
            label3.Size = new Size(49, 15);
            label3.TabIndex = 8;
            label3.Text = "Código:";
            // 
            // textBoxTipoCuenta
            // 
            textBoxTipoCuenta.Location = new Point(93, 80);
            textBoxTipoCuenta.Name = "textBoxTipoCuenta";
            textBoxTipoCuenta.Size = new Size(287, 23);
            textBoxTipoCuenta.TabIndex = 3;
            // 
            // textBoxCodigo
            // 
            textBoxCodigo.Location = new Point(93, 22);
            textBoxCodigo.Name = "textBoxCodigo";
            textBoxCodigo.Size = new Size(287, 23);
            textBoxCodigo.TabIndex = 1;
            // 
            // checkBoxEstado
            // 
            checkBoxEstado.AutoSize = true;
            checkBoxEstado.Location = new Point(387, 82);
            checkBoxEstado.Name = "checkBoxEstado";
            checkBoxEstado.Size = new Size(60, 19);
            checkBoxEstado.TabIndex = 4;
            checkBoxEstado.Text = "Activo";
            checkBoxEstado.UseVisualStyleBackColor = true;
            // 
            // textBoxDescripcion
            // 
            textBoxDescripcion.Location = new Point(94, 51);
            textBoxDescripcion.Name = "textBoxDescripcion";
            textBoxDescripcion.Size = new Size(287, 23);
            textBoxDescripcion.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(16, 54);
            label1.Name = "label1";
            label1.Size = new Size(72, 15);
            label1.TabIndex = 0;
            label1.Text = "Descripción:";
            // 
            // FormPlanCuentas
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(561, 529);
            Controls.Add(groupBox3);
            Controls.Add(btnAgregar);
            Controls.Add(btnActualizar);
            Controls.Add(btnEliminar);
            Controls.Add(groupBox2);
            Controls.Add(buttonCancelar);
            Controls.Add(buttonLimpiar);
            Controls.Add(groupBox1);
            Name = "FormPlanCuentas";
            Text = "FormPlanCuentas";
            Load += FormPlanCuentas_Load;
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridViewPlanCuentas).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox3;
        private Label label2;
        private Button buttonFiltrar;
        private TextBox textBoxFiltro;
        private Button btnAgregar;
        private Button btnActualizar;
        private Button btnEliminar;
        private GroupBox groupBox2;
        private DataGridView dataGridViewPlanCuentas;
        private Button buttonCancelar;
        private Button buttonLimpiar;
        private GroupBox groupBox1;
        private TextBox textBoxTipoCuenta;
        private TextBox textBoxCodigo;
        private CheckBox checkBoxEstado;
        private TextBox textBoxDescripcion;
        private Label label1;
        private Label label4;
        private Label label3;
    }
}