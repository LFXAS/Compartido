﻿using Demo.BL.INV;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Demo.UI.INV
{
    public partial class FormBodega : Form
    {
        private readonly BodegaBL _bodegaBL;
        private readonly TipoBodegaBL _tipoBodegaBL;
        public FormBodega()
        {
            InitializeComponent();
            _tipoBodegaBL = new TipoBodegaBL();
            _bodegaBL = new BodegaBL();
            CargarBodegas();
        }

        private void CargarBodegas()
        {
            var bodegas = _bodegaBL.ObtenerBodegasConTipoBodega();

            // Asigna la lista al DataGridView
            dataGridViewBodegas.DataSource = bodegas
                .Select(s => new
                {
                    s.Id,
                    s.Codigo,
                    TipoBodega = s.TipoBodega?.Descripcion ?? "Sin tipo bodega", // Nombre del tipo de bodega
                    s.Descripcion,
                    s.FechaCreacion,
                    s.UsuarioCrea,
                    s.FechaModificacion,
                    s.UsuarioModifica,
                    Estado = s.Estado ? "Activo" : "Inactivo"  // Cambiar visualización del estado
                })
                .ToList();

            FormateaDataGridView();
        }

        private void FormateaDataGridView()
        {
            // Configurar el DataGridView para seleccionar la fila completa al hacer clic en una celda
            dataGridViewBodegas.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            // Deshabilitar la selección de múltiples filas (opcional)
            dataGridViewBodegas.MultiSelect = false;

            // Deshabilitar la selección de celdas individuales (opcional)
            dataGridViewBodegas.CellBorderStyle = DataGridViewCellBorderStyle.None;

            // Personalizar las columnas
            dataGridViewBodegas.Columns["Id"].HeaderText = "ID";               // Cambiar encabezado de la columna
            dataGridViewBodegas.Columns["Codigo"].HeaderText = "Código"; // Cambiar encabezado de la columna
            dataGridViewBodegas.Columns["Descripcion"].HeaderText = "Bodega"; // Cambiar encabezado de la columna
            dataGridViewBodegas.Columns["TipoBodega"].HeaderText = "Tipo de bodega";  // Cambiar encabezado de la columna
            dataGridViewBodegas.Columns["FechaCreacion"].HeaderText = "Fecha de creación";
            dataGridViewBodegas.Columns["UsuarioCrea"].HeaderText = "Usuario crea";
            dataGridViewBodegas.Columns["FechaModificacion"].HeaderText = "Fecha de modificación";
            dataGridViewBodegas.Columns["UsuarioModifica"].HeaderText = "Usuario modifica";
            dataGridViewBodegas.Columns["Estado"].HeaderText = "Estado";        // Cambiar encabezado de la columna

            // Configura las filas alternas para que se vean con un fondo diferente
            dataGridViewBodegas.AlternatingRowsDefaultCellStyle.BackColor = Color.LightGray;

            // Cambiar el color de la fila seleccionada
            dataGridViewBodegas.DefaultCellStyle.SelectionBackColor = Color.Blue;
            dataGridViewBodegas.DefaultCellStyle.SelectionForeColor = Color.White;

            // Ajustar el estilo de la fuente en las celdas
            dataGridViewBodegas.DefaultCellStyle.Font = new Font("Segoe UI", 9);

            // Cambiar el modo de ajuste de las columnas
            dataGridViewBodegas.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void FormBodega_Load(object sender, EventArgs e)
        {
            // Carga las categorías en el ComboBox (necesitas implementar ObtenerCategorias en BL)
            var tipoBodega = _tipoBodegaBL.ObtenerTipoBodegas();
            comboBoxTipoBodega.DataSource = tipoBodega;
            comboBoxTipoBodega.DisplayMember = "Descripcion";  // El campo que deseas mostrar
            comboBoxTipoBodega.ValueMember = "Id";  // El valor que representa cada categoría
            comboBoxTipoBodega.SelectedIndex = -1;
        }

        private void CargarDataGridConFiltro(string filtro)
        {
            var bodegasFiltradas = _bodegaBL.ObtenerBodegasConFiltro(filtro);

            dataGridViewBodegas.DataSource = bodegasFiltradas
                .Select(s => new
                {
                    s.Id,
                    s.Codigo,
                    s.Descripcion,
                    TipoBodega = s.TipoBodega?.Descripcion ?? "Sin categoría", // Nombre de la categoría
                    s.FechaCreacion,
                    s.UsuarioCrea,
                    s.FechaModificacion,
                    s.UsuarioModifica,
                    Estado = s.Estado ? "Activo" : "Inactivo"  // Cambiar visualización del estado
                })
                .ToList();

            FormateaDataGridView();
        }

        private void buttonFiltrar_Click(object sender, EventArgs e)
        {
            string filtro = textBoxFiltro.Text;
            CargarDataGridConFiltro(filtro); // O FiltrarDataGridView(filtro) si es filtrado en memoria
        }

        private void buttonCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                var Codigo = textBoxCodigo.Text;                
                var Descripcion = textBoxDescripcion.Text;
                var TipoBodegaId = 0;

                if (comboBoxTipoBodega.SelectedValue != null)
                {
                    TipoBodegaId = (int)comboBoxTipoBodega.SelectedValue;
                }
                else
                {
                    MessageBox.Show("Por favor, seleccione un tipo de bodega.");
                }

                var fechaCreacion = DateTime.Now;
                var usuarioCrea = "UsuarioDemo";                
                var Estado = checkBoxEstado.Checked;

                // Guardar la bodega a través de la capa BL
                _bodegaBL.GuardarBodega(Codigo,Descripcion,TipoBodegaId,fechaCreacion,usuarioCrea, Estado);
                CargarBodegas();
                MessageBox.Show("Bodega guardada correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Limpiar los controles
                textBoxDescripcion.Clear();
                comboBoxTipoBodega.SelectedIndex = -1;
                checkBoxEstado.Checked = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ocurrió un error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
