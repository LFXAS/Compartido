﻿using System;

namespace Demo.UI.INV
{
    partial class FormSubcategoria
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label labelDescripcion;
        private System.Windows.Forms.TextBox textBoxDescripcion;
        private System.Windows.Forms.ComboBox comboBoxCategoria;
        private System.Windows.Forms.Label labelCategoria;
        private System.Windows.Forms.CheckBox checkBoxEstado;
        //private System.Windows.Forms.Button buttonCancelar1;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            labelDescripcion = new Label();
            textBoxDescripcion = new TextBox();
            comboBoxCategoria = new ComboBox();
            labelCategoria = new Label();
            checkBoxEstado = new CheckBox();
            groupBox1 = new GroupBox();
            groupBox2 = new GroupBox();
            label1 = new Label();
            buttonFiltrar = new Button();
            textBoxFiltro = new TextBox();
            groupBox3 = new GroupBox();
            dataGridViewSubcategorias = new DataGridView();
            btnAgregar = new Button();
            btnActualizar = new Button();
            btnEliminar = new Button();
            buttonCancelar = new Button();
            buttonLimpiar = new Button();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewSubcategorias).BeginInit();
            SuspendLayout();
            // 
            // labelDescripcion
            // 
            labelDescripcion.AutoSize = true;
            labelDescripcion.Location = new Point(13, 38);
            labelDescripcion.Name = "labelDescripcion";
            labelDescripcion.Size = new Size(90, 20);
            labelDescripcion.TabIndex = 0;
            labelDescripcion.Text = "Descripción:";
            // 
            // textBoxDescripcion
            // 
            textBoxDescripcion.Location = new Point(109, 35);
            textBoxDescripcion.Name = "textBoxDescripcion";
            textBoxDescripcion.Size = new Size(232, 27);
            textBoxDescripcion.TabIndex = 1;
            // 
            // comboBoxCategoria
            // 
            comboBoxCategoria.FormattingEnabled = true;
            comboBoxCategoria.Location = new Point(430, 35);
            comboBoxCategoria.Name = "comboBoxCategoria";
            comboBoxCategoria.Size = new Size(234, 28);
            comboBoxCategoria.TabIndex = 2;
            // 
            // labelCategoria
            // 
            labelCategoria.AutoSize = true;
            labelCategoria.Location = new Point(347, 38);
            labelCategoria.Name = "labelCategoria";
            labelCategoria.Size = new Size(77, 20);
            labelCategoria.TabIndex = 3;
            labelCategoria.Text = "Categoría:";
            // 
            // checkBoxEstado
            // 
            checkBoxEstado.AutoSize = true;
            checkBoxEstado.Location = new Point(681, 39);
            checkBoxEstado.Name = "checkBoxEstado";
            checkBoxEstado.Size = new Size(73, 24);
            checkBoxEstado.TabIndex = 4;
            checkBoxEstado.Text = "Activo";
            checkBoxEstado.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(textBoxDescripcion);
            groupBox1.Controls.Add(labelDescripcion);
            groupBox1.Controls.Add(comboBoxCategoria);
            groupBox1.Controls.Add(checkBoxEstado);
            groupBox1.Controls.Add(labelCategoria);
            groupBox1.Location = new Point(9, 9);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(763, 86);
            groupBox1.TabIndex = 7;
            groupBox1.TabStop = false;
            groupBox1.Text = "Información";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(label1);
            groupBox2.Controls.Add(buttonFiltrar);
            groupBox2.Controls.Add(textBoxFiltro);
            groupBox2.Location = new Point(9, 101);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(763, 79);
            groupBox2.TabIndex = 9;
            groupBox2.TabStop = false;
            groupBox2.Text = "Filtro";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(19, 35);
            label1.Name = "label1";
            label1.Size = new Size(171, 20);
            label1.TabIndex = 6;
            label1.Text = "Categoría/Subcategoría:";
            // 
            // buttonFiltrar
            // 
            buttonFiltrar.Location = new Point(437, 26);
            buttonFiltrar.Name = "buttonFiltrar";
            buttonFiltrar.Size = new Size(100, 30);
            buttonFiltrar.TabIndex = 5;
            buttonFiltrar.Text = "Buscar";
            buttonFiltrar.UseVisualStyleBackColor = true;
            buttonFiltrar.Click += buttonFiltrar_Click;
            // 
            // textBoxFiltro
            // 
            textBoxFiltro.Location = new Point(190, 30);
            textBoxFiltro.Name = "textBoxFiltro";
            textBoxFiltro.Size = new Size(241, 27);
            textBoxFiltro.TabIndex = 0;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(dataGridViewSubcategorias);
            groupBox3.Location = new Point(12, 186);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(760, 295);
            groupBox3.TabIndex = 8;
            groupBox3.TabStop = false;
            groupBox3.Text = "Información";
            // 
            // dataGridViewSubcategorias
            // 
            dataGridViewSubcategorias.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewSubcategorias.Location = new Point(10, 31);
            dataGridViewSubcategorias.Name = "dataGridViewSubcategorias";
            dataGridViewSubcategorias.RowHeadersWidth = 51;
            dataGridViewSubcategorias.Size = new Size(739, 243);
            dataGridViewSubcategorias.TabIndex = 0;
            // 
            // btnAgregar
            // 
            btnAgregar.Location = new Point(12, 504);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new Size(100, 30);
            btnAgregar.TabIndex = 26;
            btnAgregar.Text = "Agregar";
            btnAgregar.Click += btnAgregar_Click;
            // 
            // btnActualizar
            // 
            btnActualizar.Enabled = false;
            btnActualizar.Location = new Point(118, 504);
            btnActualizar.Name = "btnActualizar";
            btnActualizar.Size = new Size(100, 30);
            btnActualizar.TabIndex = 27;
            btnActualizar.Text = "Actualizar";
            // 
            // btnEliminar
            // 
            btnEliminar.Enabled = false;
            btnEliminar.Location = new Point(224, 504);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new Size(100, 30);
            btnEliminar.TabIndex = 28;
            btnEliminar.Text = "Eliminar";
            // 
            // buttonCancelar
            // 
            buttonCancelar.Location = new Point(672, 504);
            buttonCancelar.Name = "buttonCancelar";
            buttonCancelar.Size = new Size(100, 30);
            buttonCancelar.TabIndex = 25;
            buttonCancelar.Text = "Cancelar";
            buttonCancelar.UseVisualStyleBackColor = true;
            buttonCancelar.Click += buttonCancelar_Click;
            // 
            // buttonLimpiar
            // 
            buttonLimpiar.Location = new Point(566, 504);
            buttonLimpiar.Name = "buttonLimpiar";
            buttonLimpiar.Size = new Size(100, 30);
            buttonLimpiar.TabIndex = 24;
            buttonLimpiar.Text = "Limpiar";
            buttonLimpiar.UseVisualStyleBackColor = true;
            // 
            // FormSubcategoria
            // 
            ClientSize = new Size(788, 558);
            Controls.Add(btnAgregar);
            Controls.Add(btnActualizar);
            Controls.Add(btnEliminar);
            Controls.Add(buttonCancelar);
            Controls.Add(buttonLimpiar);
            Controls.Add(groupBox2);
            Controls.Add(groupBox3);
            Controls.Add(groupBox1);
            MaximizeBox = false;
            Name = "FormSubcategoria";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Creación de subcategoría";
            Load += FormSubcategoria_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridViewSubcategorias).EndInit();
            ResumeLayout(false);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        /*private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Text = "FormSubcategoria";
        }*/

        #endregion

        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private Label label1;
        private Button buttonFiltrar;
        private TextBox textBoxFiltro;
        private GroupBox groupBox3;
        private DataGridView dataGridViewSubcategorias;
        private Button btnAgregar;
        private Button btnActualizar;
        private Button btnEliminar;
        private Button buttonCancelar;
        private Button buttonLimpiar;
    }
}