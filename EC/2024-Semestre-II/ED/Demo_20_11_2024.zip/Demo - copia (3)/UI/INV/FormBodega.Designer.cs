﻿namespace Demo.UI.INV
{
    partial class FormBodega
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnAgregar = new Button();
            btnActualizar = new Button();
            btnEliminar = new Button();
            buttonCancelar = new Button();
            buttonLimpiar = new Button();
            groupBox2 = new GroupBox();
            label1 = new Label();
            buttonFiltrar = new Button();
            textBoxFiltro = new TextBox();
            groupBox3 = new GroupBox();
            dataGridViewBodegas = new DataGridView();
            groupBox1 = new GroupBox();
            textBoxCodigo = new TextBox();
            label2 = new Label();
            textBoxDescripcion = new TextBox();
            labelDescripcion = new Label();
            comboBoxTipoBodega = new ComboBox();
            checkBoxEstado = new CheckBox();
            labelCategoria = new Label();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewBodegas).BeginInit();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // btnAgregar
            // 
            btnAgregar.Location = new Point(13, 563);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new Size(100, 30);
            btnAgregar.TabIndex = 34;
            btnAgregar.Text = "Agregar";
            btnAgregar.Click += btnAgregar_Click;
            // 
            // btnActualizar
            // 
            btnActualizar.Enabled = false;
            btnActualizar.Location = new Point(119, 563);
            btnActualizar.Name = "btnActualizar";
            btnActualizar.Size = new Size(100, 30);
            btnActualizar.TabIndex = 35;
            btnActualizar.Text = "Actualizar";
            // 
            // btnEliminar
            // 
            btnEliminar.Enabled = false;
            btnEliminar.Location = new Point(225, 563);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new Size(100, 30);
            btnEliminar.TabIndex = 36;
            btnEliminar.Text = "Eliminar";
            // 
            // buttonCancelar
            // 
            buttonCancelar.Location = new Point(673, 563);
            buttonCancelar.Name = "buttonCancelar";
            buttonCancelar.Size = new Size(100, 30);
            buttonCancelar.TabIndex = 33;
            buttonCancelar.Text = "Cancelar";
            buttonCancelar.UseVisualStyleBackColor = true;
            buttonCancelar.Click += buttonCancelar_Click;
            // 
            // buttonLimpiar
            // 
            buttonLimpiar.Location = new Point(567, 563);
            buttonLimpiar.Name = "buttonLimpiar";
            buttonLimpiar.Size = new Size(100, 30);
            buttonLimpiar.TabIndex = 32;
            buttonLimpiar.Text = "Limpiar";
            buttonLimpiar.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(label1);
            groupBox2.Controls.Add(buttonFiltrar);
            groupBox2.Controls.Add(textBoxFiltro);
            groupBox2.Location = new Point(10, 162);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(763, 79);
            groupBox2.TabIndex = 31;
            groupBox2.TabStop = false;
            groupBox2.Text = "Filtro";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(19, 35);
            label1.Name = "label1";
            label1.Size = new Size(152, 20);
            label1.TabIndex = 6;
            label1.Text = "TipoBodega/Bodega:";
            // 
            // buttonFiltrar
            // 
            buttonFiltrar.Location = new Point(437, 26);
            buttonFiltrar.Name = "buttonFiltrar";
            buttonFiltrar.Size = new Size(100, 30);
            buttonFiltrar.TabIndex = 5;
            buttonFiltrar.Text = "Buscar";
            buttonFiltrar.UseVisualStyleBackColor = true;
            buttonFiltrar.Click += buttonFiltrar_Click;
            // 
            // textBoxFiltro
            // 
            textBoxFiltro.Location = new Point(190, 30);
            textBoxFiltro.Name = "textBoxFiltro";
            textBoxFiltro.Size = new Size(241, 27);
            textBoxFiltro.TabIndex = 0;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(dataGridViewBodegas);
            groupBox3.Location = new Point(10, 247);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(760, 295);
            groupBox3.TabIndex = 30;
            groupBox3.TabStop = false;
            groupBox3.Text = "Información";
            // 
            // dataGridViewBodegas
            // 
            dataGridViewBodegas.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewBodegas.Location = new Point(10, 31);
            dataGridViewBodegas.Name = "dataGridViewBodegas";
            dataGridViewBodegas.RowHeadersWidth = 51;
            dataGridViewBodegas.Size = new Size(739, 243);
            dataGridViewBodegas.TabIndex = 0;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(textBoxCodigo);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(textBoxDescripcion);
            groupBox1.Controls.Add(labelDescripcion);
            groupBox1.Controls.Add(comboBoxTipoBodega);
            groupBox1.Controls.Add(checkBoxEstado);
            groupBox1.Controls.Add(labelCategoria);
            groupBox1.Location = new Point(10, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(763, 144);
            groupBox1.TabIndex = 29;
            groupBox1.TabStop = false;
            groupBox1.Text = "Información";
            // 
            // textBoxCodigo
            // 
            textBoxCodigo.Location = new Point(133, 24);
            textBoxCodigo.Name = "textBoxCodigo";
            textBoxCodigo.Size = new Size(232, 27);
            textBoxCodigo.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(15, 24);
            label2.Name = "label2";
            label2.Size = new Size(61, 20);
            label2.TabIndex = 5;
            label2.Text = "Código:";
            // 
            // textBoxDescripcion
            // 
            textBoxDescripcion.Location = new Point(133, 63);
            textBoxDescripcion.Name = "textBoxDescripcion";
            textBoxDescripcion.Size = new Size(232, 27);
            textBoxDescripcion.TabIndex = 2;
            // 
            // labelDescripcion
            // 
            labelDescripcion.AutoSize = true;
            labelDescripcion.Location = new Point(11, 66);
            labelDescripcion.Name = "labelDescripcion";
            labelDescripcion.Size = new Size(90, 20);
            labelDescripcion.TabIndex = 0;
            labelDescripcion.Text = "Descripción:";
            // 
            // comboBoxTipoBodega
            // 
            comboBoxTipoBodega.FormattingEnabled = true;
            comboBoxTipoBodega.Location = new Point(131, 103);
            comboBoxTipoBodega.Name = "comboBoxTipoBodega";
            comboBoxTipoBodega.Size = new Size(234, 28);
            comboBoxTipoBodega.TabIndex = 3;
            // 
            // checkBoxEstado
            // 
            checkBoxEstado.AutoSize = true;
            checkBoxEstado.Location = new Point(382, 107);
            checkBoxEstado.Name = "checkBoxEstado";
            checkBoxEstado.Size = new Size(73, 24);
            checkBoxEstado.TabIndex = 4;
            checkBoxEstado.Text = "Activo";
            checkBoxEstado.UseVisualStyleBackColor = true;
            // 
            // labelCategoria
            // 
            labelCategoria.AutoSize = true;
            labelCategoria.Location = new Point(10, 106);
            labelCategoria.Name = "labelCategoria";
            labelCategoria.Size = new Size(119, 20);
            labelCategoria.TabIndex = 3;
            labelCategoria.Text = "Tipo de bodega:";
            // 
            // FormBodega
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(785, 605);
            Controls.Add(btnAgregar);
            Controls.Add(btnActualizar);
            Controls.Add(btnEliminar);
            Controls.Add(buttonCancelar);
            Controls.Add(buttonLimpiar);
            Controls.Add(groupBox2);
            Controls.Add(groupBox3);
            Controls.Add(groupBox1);
            Name = "FormBodega";
            Text = "FormBodega";
            Load += FormBodega_Load;
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridViewBodegas).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Button btnAgregar;
        private Button btnActualizar;
        private Button btnEliminar;
        private Button buttonCancelar;
        private Button buttonLimpiar;
        private GroupBox groupBox2;
        private Label label1;
        private Button buttonFiltrar;
        private TextBox textBoxFiltro;
        private GroupBox groupBox3;
        private DataGridView dataGridViewBodegas;
        private GroupBox groupBox1;
        private TextBox textBoxCodigo;
        private Label label2;
        private TextBox textBoxDescripcion;
        private Label labelDescripcion;
        private ComboBox comboBoxTipoBodega;
        private CheckBox checkBoxEstado;
        private Label labelCategoria;
    }
}