﻿using Demo.DTO.INV;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace Demo.DAL.INV
{
    public class BodegaDbContext:DbContext
    {
        public DbSet<BodegaDTO> Bodegas { get; set; }

        public BodegaDbContext() : base(GetOptions()) { }

        private static DbContextOptions<BodegaDbContext> GetOptions()
        {
            var connectionString = ConfigurationManager.ConnectionStrings["SISFACDB"].ConnectionString;

            if (connectionString == null)
            {
                throw new InvalidOperationException("Cadena de conexión 'SISFACDB' no encontrada en App.config.");
            }

            return SqlServerDbContextOptionsExtensions.UseSqlServer(new DbContextOptionsBuilder<BodegaDbContext>(), connectionString).Options;
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<BodegaDTO>().ToTable("inv_bodega");
            // Definir la clave primaria
            modelBuilder.Entity<BodegaDTO>().HasKey(s => s.Id);

            // Mapeo de la relación entre Bodega y tipo de bodega
            modelBuilder.Entity<BodegaDTO>()
                .HasOne(s => s.TipoBodega)
                .WithMany(c => c.Bodegas)
                .HasForeignKey(s => s.TipoBodegaId)
                .IsRequired()
                .OnDelete(DeleteBehavior.Cascade);  // Opcional: Define el comportamiento al eliminar un tipo de bodega

            // Mapeo de la propiedad TipoBodegaId a la columna id_tipo_bodega en la base de datos
            modelBuilder.Entity<BodegaDTO>()
                .Property(s => s.TipoBodegaId)
                .HasColumnName("id_tipo_bodega");

            // Definir el resto de propiedades
            modelBuilder.Entity<BodegaDTO>()
                .Property(c => c.Codigo)
                .IsRequired()
                .HasMaxLength(15);

            modelBuilder.Entity<BodegaDTO>()
                .Property(s => s.Descripcion)
                .IsRequired()
                .HasMaxLength(50);

            modelBuilder.Entity<BodegaDTO>()
                .Property(c => c.FechaCreacion)
                .HasColumnName("fecha_creacion");

            modelBuilder.Entity<BodegaDTO>()
                .Property(c => c.UsuarioCrea)
                .HasColumnName("usuario_crea");

            modelBuilder.Entity<BodegaDTO>()
                .Property(c => c.FechaModificacion)
                .HasColumnName("fecha_modificacion");

            modelBuilder.Entity<BodegaDTO>()
                .Property(c => c.UsuarioModifica)
                .HasColumnName("usuario_modifica");

            modelBuilder.Entity<BodegaDTO>()
                .Property(s => s.Estado)
                .IsRequired();

            modelBuilder.Entity<TipoBodegaDTO>().ToTable("inv_tipo_bodega");

            modelBuilder.Entity<TipoBodegaDTO>().HasKey(c => c.Id);

     
            modelBuilder.Entity<TipoBodegaDTO>()
                .Property(c => c.Descripcion)
                .IsRequired()
                .HasMaxLength(50);

            modelBuilder.Entity<TipoBodegaDTO>()
                .Property(c => c.FechaCreacion)
                .HasColumnName("fecha_creacion");

            modelBuilder.Entity<TipoBodegaDTO>()
                .Property(c => c.UsuarioCrea)
                .HasColumnName("usuario_crea");

            modelBuilder.Entity<TipoBodegaDTO>()
                .Property(c => c.FechaModificacion)
                .HasColumnName("fecha_modificacion");

            modelBuilder.Entity<TipoBodegaDTO>()
                .Property(c => c.UsuarioModifica)
                .HasColumnName("usuario_modifica");

            modelBuilder.Entity<TipoBodegaDTO>()
                .Property(c => c.Estado)
                .IsRequired();
        }
    }
}
