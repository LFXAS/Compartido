﻿using Demo.DTO.INV;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace Demo.DAL.INV
{
    public class BodegaDAL
    {
        private readonly BodegaDbContext _context;

        public BodegaDAL()
        {
            _context = new BodegaDbContext();
        }

        // Método para obtener todas las subcategorías
        public List<BodegaDTO> ObtenerBodegas()
        {
            return _context.Bodegas.ToList();
        }

        // Método para obtener una subcategoría por su Id
        public BodegaDTO ObtenerBodegaPorId(int id)
        {
            var bodega = _context.Bodegas.FirstOrDefault(s => s.Id == id);

            if (bodega == null)
            {
                // Maneja el caso en el que no se encuentra el tipo de bodega
                throw new Exception($"No se encontró ningun tipo de bodega con el ID {id}");
            }
            return bodega;
        }

        // Método para obtener todas las subcategorías con su respectiva categoría
        public List<BodegaDTO> ObtenerBodegasConTipoBodega()
        {
            return _context.Bodegas
                           .Include(s => s.TipoBodega)  // carga de la relación Tipo de bodega
                           .ToList();
        }

        public List<BodegaDTO> ObtenerBodegasPorTipoBodega(int tipoBodegaId)
        {
            return _context.Bodegas
                           .Where(s => s.TipoBodegaId == tipoBodegaId)
                           .ToList();
        }

        public List<BodegaDTO> ObtenerBodegasConFiltro(string filtro)
        {
            using (var context = new BodegaDbContext())
            {
                var bodegasFiltradas = context.Bodegas
                    .Include(s => s.TipoBodega)
                    .Where(s => s.Descripcion.Contains(filtro)
                             || (s.TipoBodega != null && s.TipoBodega.Descripcion.Contains(filtro)))
                    .ToList();

                return bodegasFiltradas;
            }

        }

        // Método para insertar una nueva subcategoría
        public void InsertarBodega(BodegaDTO bodega)
        {
            _context.Bodegas.Add(bodega);
            _context.SaveChanges();
        }

        // Método para actualizar una bodega existente
        public void ActualizarBodega(BodegaDTO bodega)
        {
            var bodegaExistente = _context.Bodegas.FirstOrDefault(s => s.Id == bodega.Id);
            if (bodegaExistente != null)
            {
                bodegaExistente.Descripcion = bodega.Descripcion;
                bodegaExistente.TipoBodegaId = bodega.TipoBodegaId;
                bodegaExistente.Estado = bodega.Estado;

                _context.SaveChanges();
            }
        }

        // Método para eliminar una bodega
        public void EliminarBodega(int id)
        {
            var bodega = _context.Bodegas.FirstOrDefault(s => s.Id == id);
            if (bodega != null)
            {
                _context.Bodegas.Remove(bodega);
                _context.SaveChanges();
            }
        }
    }
}
