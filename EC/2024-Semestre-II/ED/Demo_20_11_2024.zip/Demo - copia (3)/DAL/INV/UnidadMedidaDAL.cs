﻿using Demo.DTO.INV;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Demo.DAL.INV
{
    public class UnidadMedidaDAL
    {
        private readonly UnidadMedidaDbContext _context;

        public UnidadMedidaDAL()
        {
            _context = new UnidadMedidaDbContext();
        }

        public List<UnidadMedidaDTO> ObtenerUnidadMedidas()
        {
            //return _context.UnidadMedidas.ToList();
            return _context.UnidadMedidas
                .Select(i => new UnidadMedidaDTO
                {
                    Id = i.Id,
                    Siglas = i.Siglas,
                    Descripcion = i.Descripcion,
                    FechaCreacion = i.FechaCreacion ?? null,
                    UsuarioCrea = i.UsuarioCrea ?? null,
                    // Manejo de campos opcionales
                    FechaModificacion = i.FechaModificacion ?? null,
                    UsuarioModifica = i.UsuarioModifica ?? null,
                    Estado = i.Estado
                })
                .ToList();
        }

        public List<UnidadMedidaDTO> ObtenerUnidadMedidaConFiltro(string filtro)
        {
            using (var context = new UnidadMedidaDbContext())
            {
                var unidadMedidaFiltradas = context.UnidadMedidas
                    .Where(s => s.Descripcion.Contains(filtro))
                    .ToList();
                return unidadMedidaFiltradas;
            }

        }

        public void InsertarUnidadMedida(UnidadMedidaDTO unidadMedida)
        {
            _context.UnidadMedidas.Add(unidadMedida);
            _context.SaveChanges();
        }

        public UnidadMedidaDTO ObtenerUnidadMedidaPorId(int id)
        {
            var unidadMedida = _context.UnidadMedidas.FirstOrDefault(m => m.Id == id);

            if (unidadMedida == null)
            {
                // Maneja el caso en el que no se encuentra la unidad de medida
                throw new Exception($"No se encontró ninguna unidad de medida con el ID {id}");
            }

            return unidadMedida;

        }

        public void ActualizarUnidadMedida(UnidadMedidaDTO unidadMedida)
        {
            //_context.UnidadMedidas.Update(unidadMedida);
            //_context.SaveChanges();
            var entidadExistente = _context.UnidadMedidas.Local.FirstOrDefault(e => e.Id == unidadMedida.Id);

            if (entidadExistente != null)
            {
                _context.Entry(entidadExistente).State = EntityState.Detached; // Desadjuntar la entidad
            }

            _context.Entry(unidadMedida).State = EntityState.Modified; // Adjuntar y marcar como modificada
            _context.SaveChanges();
        }

        public void EliminarUnidadMedida(int id)
        {
            var unidadMedida = _context.UnidadMedidas.FirstOrDefault(m => m.Id == id);
            if (unidadMedida != null)
            {
                _context.UnidadMedidas.Remove(unidadMedida);
                _context.SaveChanges();
            }
        }
    }
}
