﻿using Demo.DTO.INV;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace Demo.DAL.INV
{
    class TipoBodegaDbContext : DbContext
    {
        public DbSet<TipoBodegaDTO> TipoBodegas { get; set; }

        public TipoBodegaDbContext() : base(GetOptions()) { }

        private static DbContextOptions<TipoBodegaDbContext> GetOptions()
        {
            var connectionString = ConfigurationManager.ConnectionStrings["SISFACDB"].ConnectionString;

            if (connectionString == null)
            {
                throw new InvalidOperationException("Cadena de conexión 'SISFACDB' no encontrada en App.config.");
            }

            return SqlServerDbContextOptionsExtensions.UseSqlServer(new DbContextOptionsBuilder<TipoBodegaDbContext>(), connectionString).Options;
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<TipoBodegaDTO>().ToTable("inv_tipo_bodega");
            modelBuilder.Entity<TipoBodegaDTO>().HasKey(m => m.Id);
            modelBuilder.Entity<TipoBodegaDTO>().Property(m => m.Descripcion).IsRequired().HasMaxLength(50);

            modelBuilder.Entity<TipoBodegaDTO>()
                .Property(m => m.FechaCreacion)
                .HasColumnName("fecha_creacion");

            modelBuilder.Entity<TipoBodegaDTO>()
                .Property(m => m.UsuarioCrea)
                .HasColumnName("usuario_crea");

            modelBuilder.Entity<TipoBodegaDTO>()
                .Property(m => m.FechaModificacion)
                .HasColumnName("fecha_modificacion");

            modelBuilder.Entity<TipoBodegaDTO>()
                .Property(m => m.UsuarioModifica)
                .HasColumnName("usuario_modifica");

            modelBuilder.Entity<TipoBodegaDTO>().Property(m => m.Estado).IsRequired();
        }
    }
}
