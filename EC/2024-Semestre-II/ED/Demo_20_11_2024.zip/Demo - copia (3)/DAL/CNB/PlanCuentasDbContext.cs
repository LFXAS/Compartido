﻿using Demo.DTO.CNB;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace Demo.DAL.CNB
{
    public class PlanCuentasDbContext:DbContext
    {
        public DbSet<PlanCuentasDTO> PlanCuentas { get; set; }

        public PlanCuentasDbContext() : base(GetOptions()) { }

        private static DbContextOptions<PlanCuentasDbContext> GetOptions()
        {
            var connectionString = ConfigurationManager.ConnectionStrings["SISFACDB"].ConnectionString;

            if (connectionString == null)
            {
                throw new InvalidOperationException("Cadena de conexión 'SISFACDB' no encontrada en App.config.");
            }

            return SqlServerDbContextOptionsExtensions.UseSqlServer(new DbContextOptionsBuilder<PlanCuentasDbContext>(), connectionString).Options;
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<PlanCuentasDTO>().ToTable("con_plan_cuentas");
            modelBuilder.Entity<PlanCuentasDTO>().HasKey(m => m.Id);
            modelBuilder.Entity<PlanCuentasDTO>().Property(m => m.Codigo).IsRequired()
                .HasColumnName("codigo_cuenta");
            modelBuilder.Entity<PlanCuentasDTO>().Property(m => m.Descripcion).IsRequired().HasMaxLength(50)
                .HasColumnName("nombre_cuenta");
            modelBuilder.Entity<PlanCuentasDTO>().Property(m => m.TipoCuenta).IsRequired().HasMaxLength(15)
                .HasColumnName("tipo_cuenta");
            modelBuilder.Entity<PlanCuentasDTO>()
                .Property(m => m.FechaCreacion)
                .HasColumnName("fecha_creacion");

            modelBuilder.Entity<PlanCuentasDTO>()
                .Property(m => m.UsuarioCrea)
                .HasColumnName("usuario_crea");

            modelBuilder.Entity<PlanCuentasDTO>()
                .Property(m => m.FechaModificacion)
                .HasColumnName("fecha_modificacion");

            modelBuilder.Entity<PlanCuentasDTO>()
                .Property(m => m.UsuarioModifica)
                .HasColumnName("usuario_modifica");

            modelBuilder.Entity<PlanCuentasDTO>().Property(m => m.Estado).IsRequired();
        }
    }
}
