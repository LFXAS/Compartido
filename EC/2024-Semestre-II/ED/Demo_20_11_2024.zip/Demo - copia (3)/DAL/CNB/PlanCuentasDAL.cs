﻿using Demo.DAL.CNB;
using Demo.DTO.CNB;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo.DAL.CNB
{
    public class PlanCuentasDAL
    {
        private readonly PlanCuentasDbContext _context;

        public PlanCuentasDAL()
        {
            _context = new PlanCuentasDbContext();
        }

        /*public List<MarcaDTO> ObtenerMarcas()
        {
            return _context.Marcas.ToList();
        }*/

        public List<PlanCuentasDTO> ObtenerPlanCuentas()
        {
            return _context.PlanCuentas
                .Select(i => new PlanCuentasDTO
                {
                    Id = i.Id,
                    Codigo = i.Codigo,
                    Descripcion = i.Descripcion,
                    TipoCuenta = i.TipoCuenta,
                    FechaCreacion = i.FechaCreacion ?? null,
                    UsuarioCrea = i.UsuarioCrea ?? null,
                    // Manejo de campos opcionales
                    FechaModificacion = i.FechaModificacion ?? null,
                    UsuarioModifica = i.UsuarioModifica ?? null,
                    Estado = i.Estado
                })
                .ToList();
        }

        public List<PlanCuentasDTO> ObtenerPlanCuentasConFiltro(string filtro)
        {
            using (var context = new PlanCuentasDbContext())
            {
                var planCuentasFiltradas = context.PlanCuentas
                    .Where(s => s.Descripcion.Contains(filtro))
                    .ToList();
                return planCuentasFiltradas;
            }

        }

        public void InsertarPlanCuentas(PlanCuentasDTO planCuentas)
        {
            _context.PlanCuentas.Add(planCuentas);
            _context.SaveChanges();
        }

        public PlanCuentasDTO ObtenerPlanCuentasPorId(int id)
        {
            var planCuentas = _context.PlanCuentas.FirstOrDefault(m => m.Id == id);

            if (planCuentas == null)
            {
                // Maneja el caso en el que no se encuentra la marca
                throw new Exception($"No se encontró ningun plan cuentas con el ID {id}");
            }
            return planCuentas;
        }

        public void ActualizarPlanCuentas(PlanCuentasDTO planCuentas)
        {
            //_context.Marcas.Update(marca);
            //_context.SaveChanges();
            var entidadExistente = _context.PlanCuentas.Local.FirstOrDefault(e => e.Id == planCuentas.Id);

            if (entidadExistente != null)
            {
                _context.Entry(entidadExistente).State = EntityState.Detached; // Desadjuntar la entidad
            }

            _context.Entry(planCuentas).State = EntityState.Modified; // Adjuntar y marcar como modificada
            _context.SaveChanges();
        }

        public void EliminarPlanCuentas(int id)
        {
            var planCuentas = _context.PlanCuentas.FirstOrDefault(m => m.Id == id);
            if (planCuentas != null)
            {
                _context.PlanCuentas.Remove(planCuentas);
                _context.SaveChanges();
            }
        }
    }
}
