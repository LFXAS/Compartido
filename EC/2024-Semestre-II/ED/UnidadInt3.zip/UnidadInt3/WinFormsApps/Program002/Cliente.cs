﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApps.Program002
{
    public class Cliente:Persona
    {
        public double Monto {  get; set; }        
    }
}
