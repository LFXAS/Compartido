﻿using SISFAC.Negocio.INV;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SISFAC.Front.INV
{
    public partial class FormMarca : Form
    {
        private readonly MarcaBL _marcaBl;

        public FormMarca()
        {
            InitializeComponent();
            _marcaBl = new MarcaBL();
        }

        private void buttonCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonAceptar_Click(object sender, EventArgs e)
        {
            // Validar los campos antes de guardar
            if (string.IsNullOrEmpty(textBoxDescripcion.Text))
            {
                MessageBox.Show("La descripción es requerida.");
                return;
            }

            var descripcion = textBoxDescripcion.Text;
            //var estado = chkEstado.Checked;

            // Guardar la marca usando la capa de lógica de negocio
            _marcaBl.GuardarMarca(descripcion);

            MessageBox.Show("Marca guardada correctamente.");

            // Limpiar los campos
            textBoxDescripcion.Text = string.Empty;
            //chkEstado.Checked = false;
        }
    }
}
