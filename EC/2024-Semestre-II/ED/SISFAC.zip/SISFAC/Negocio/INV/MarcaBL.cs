﻿using SISFAC.Entidades.INV;
using SISFAC.Datos.INV;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SISFAC.Negocio.INV
{
    public class MarcaBL
    {
        private readonly MarcaDAL _marcaDal;        
         /* La palabra clave readonly en C# se utiliza para definir un campo que solo puede ser 
         * asignado durante la inicialización de la instancia del objeto, ya sea en la 
         * declaración del campo o en el constructor de la clase. 
         * Una vez que se ha asignado un valor a un campo marcado como readonly, 
         * no puede ser modificado posteriormente (excepto en el constructor).
         */
         

        public MarcaBL()
        {
            _marcaDal = new MarcaDAL();
        }

        public List<MarcaDTO> ObtenerMarcas()
        {
            return _marcaDal.ObtenerMarcas();
        }

        public void GuardarMarca(string descripcion)
        {
            var marca = new MarcaDTO
            {
                Descripcion = descripcion
                //Estado = estado
            };

            _marcaDal.InsertarMarca(marca);
        }

        public MarcaDTO ObtenerMarcaPorId(int id)
        {
            return _marcaDal.ObtenerMarcaPorId(id);
        }

        public void ActualizarMarca(MarcaDTO marca)
        {
            _marcaDal.ActualizarMarca(marca);
        }

        public void EliminarMarca(int id)
        {
            _marcaDal.EliminarMarca(id);
        }
    }
}
