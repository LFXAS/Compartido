﻿using SISFAC.Entidades.INV;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SISFAC.Datos.INV
{
    public class MarcaDAL
    {
        private readonly MarcaDbContext _context;

        public MarcaDAL()
        {
            _context = new MarcaDbContext();
        }

        public List<MarcaDTO> ObtenerMarcas()
        {
            return _context.Marcas.ToList();
        }

        public void InsertarMarca(MarcaDTO marca)
        {
            _context.Marcas.Add(marca);
            _context.SaveChanges();
        }

        public MarcaDTO ObtenerMarcaPorId(int id)
        {
            //return _context.Marcas.FirstOrDefault(m => m.Id == id);
            //return _context.Marcas.First(m => m.Id == id);  // Esto lanzará una excepción si no hay coincidencias
            
            var marca = _context.Marcas.FirstOrDefault(m => m.Id == id);

            if (marca == null)
            {
                // Maneja el caso en el que no se encuentra la marca
                throw new Exception($"No se encontró ninguna marca con el ID {id}");
            }

            return marca;           
        }

        public void ActualizarMarca(MarcaDTO marca)
        {
            _context.Marcas.Update(marca);
            _context.SaveChanges();
        }

        public void EliminarMarca(int id)
        {
            var marca = _context.Marcas.FirstOrDefault(m => m.Id == id);
            if (marca != null)
            {
                _context.Marcas.Remove(marca);
                _context.SaveChanges();
            }
        }
    }
}
