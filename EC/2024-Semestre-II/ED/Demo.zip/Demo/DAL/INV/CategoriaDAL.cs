﻿using Demo.DTO.INV;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo.DAL.INV
{
    public class CategoriaDAL
    {
        private readonly CategoriaDbContext _context;

        public CategoriaDAL()
        {
            _context = new CategoriaDbContext();
        }

        public List<CategoriaDTO> ObtenerCategorias()
        {
            return _context.Categorias.ToList();
        }

        public void InsertarCategoria(CategoriaDTO categoria)
        {
            _context.Categorias.Add(categoria);
            _context.SaveChanges();
        }

        public CategoriaDTO ObtenerCategoriaPorId(int id)
        {           
            var categoria = _context.Categorias.FirstOrDefault(m => m.Id == id);

            if (categoria == null)
            {
                // Maneja el caso en el que no se encuentra la categoria
                throw new Exception($"No se encontró ninguna categoría con el ID {id}");
            }

            return categoria;

        }

        public void ActualizarCategoria(CategoriaDTO categoria)
        {
            _context.Categorias.Update(categoria);
            _context.SaveChanges();
        }

        public void EliminarCategoria(int id)
        {
            var categoria = _context.Categorias.FirstOrDefault(m => m.Id == id);
            if (categoria != null)
            {
                _context.Categorias.Remove(categoria);
                _context.SaveChanges();
            }
        }
    }
}
