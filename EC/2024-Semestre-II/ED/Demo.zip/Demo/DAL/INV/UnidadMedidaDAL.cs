﻿using Demo.DTO.INV;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo.DAL.INV
{
    public class UnidadMedidaDAL
    {
        private readonly UnidadMedidaDbContext _context;

        public UnidadMedidaDAL()
        {
            _context = new UnidadMedidaDbContext();
        }

        public List<UnidadMedidaDTO> ObtenerUnidadMedidas()
        {
            return _context.UnidadMedidas.ToList();
        }

        public void InsertarUnidadMedida(UnidadMedidaDTO unidadMedida)
        {
            _context.UnidadMedidas.Add(unidadMedida);
            _context.SaveChanges();
        }

        public UnidadMedidaDTO ObtenerUnidadMedidaPorId(int id)
        {
            var unidadMedida = _context.UnidadMedidas.FirstOrDefault(m => m.Id == id);

            if (unidadMedida == null)
            {
                // Maneja el caso en el que no se encuentra la unidad de medida
                throw new Exception($"No se encontró ninguna unidad de medida con el ID {id}");
            }

            return unidadMedida;

        }

        public void ActualizarUnidadMedida(UnidadMedidaDTO unidadMedida)
        {
            _context.UnidadMedidas.Update(unidadMedida);
            _context.SaveChanges();
        }

        public void EliminarUnidadMedida(int id)
        {
            var unidadMedida = _context.UnidadMedidas.FirstOrDefault(m => m.Id == id);
            if (unidadMedida != null)
            {
                _context.UnidadMedidas.Remove(unidadMedida);
                _context.SaveChanges();
            }
        }
    }
}
