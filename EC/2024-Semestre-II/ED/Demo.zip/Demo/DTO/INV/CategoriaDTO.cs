﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo.DTO.INV
{
    public class CategoriaDTO
    {
        public int Id { get; set; }
        public string Descripcion { get; set; } = string.Empty;
        public bool Estado { get; set; } = false;

        // Colección de subcategorías relacionadas
        public ICollection<SubcategoriaDTO>? Subcategorias { get; set; }
    }
}
