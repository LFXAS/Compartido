﻿using Demo.BL.INV;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Demo.UI.INV
{
    public partial class FormCategoria : Form
    {
        private readonly CategoriaBL _categoriaBl;
        public FormCategoria()
        {
            InitializeComponent();
            _categoriaBl = new CategoriaBL();
        }

        private void buttonGuardar_Click(object sender, EventArgs e)
        {
            // Validar los campos antes de guardar
            if (string.IsNullOrEmpty(textBoxDescripcion.Text))
            {
                MessageBox.Show("La descripción es requerida.");
                return;
            }

            var descripcion = textBoxDescripcion.Text;
            var estado = checkBoxEstado.Checked;

            // Guardar la marca usando la capa de lógica de negocio
            _categoriaBl.GuardarCategoria(descripcion, estado);

            MessageBox.Show("Categoria guardada correctamente.");

            // Limpiar los campos
            textBoxDescripcion.Text = string.Empty;
            checkBoxEstado.Checked = false;
        }

        private void buttonCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
