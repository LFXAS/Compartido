﻿using Demo.DAL.INV;
using Demo.DTO.INV;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo.BL.INV
{
    public class UnidadMedidaBL
    {
        private readonly UnidadMedidaDAL _unidadMedidaDal;

        public UnidadMedidaBL()
        {
            _unidadMedidaDal = new UnidadMedidaDAL();
        }

        public List<UnidadMedidaDTO> ObtenerUnidadMedidas()
        {
            return _unidadMedidaDal.ObtenerUnidadMedidas();
        }

        public void GuardarUnidadMedida(string siglas, string descripcion, bool estado)
        {
            var unidadMedida = new UnidadMedidaDTO
            {
                Siglas = siglas,
                Descripcion = descripcion,
                Estado = estado
            };

            _unidadMedidaDal.InsertarUnidadMedida(unidadMedida);
        }

        public UnidadMedidaDTO ObtenerUnidadMedidaPorId(int id)
        {
            return _unidadMedidaDal.ObtenerUnidadMedidaPorId(id);
        }

        public void ActualizarUnidadMedida(UnidadMedidaDTO unidadMedida)
        {
            _unidadMedidaDal.ActualizarUnidadMedida(unidadMedida);
        }

        public void EliminarUnidadMedida(int id)
        {
            _unidadMedidaDal.EliminarUnidadMedida(id);
        }
    }
}
